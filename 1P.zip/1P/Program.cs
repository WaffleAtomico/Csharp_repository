﻿//margins
// {index[,alignment] [:FormatString]}

string pearText = "Pear";
int pearCount = 12345;
string pricklyPearText = "Prickly Pear";
int pricklyPearCount = 4500;

//HEADERS
//todo margen se genera en el eje X, negativo izq, pos der
WriteLine(
    format: "{0,-10} {1, 6}"
    arg0: "Name",
    arg1: "Count"
    );