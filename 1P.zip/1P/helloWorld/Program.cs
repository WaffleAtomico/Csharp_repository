﻿using static System.Console; //con tabulador se completa
//tipos nativos
#region Native types
    int number =1;
    float number1 = 1.2F;
    double number2 = 2.4; //todo numero double necesita una letra M al final
    bool isTrue = false;
    char character = 'A';
#endregion


//tipos complejos
#region  Complex types
    string name = "Victor";
    DateTime dateOfBirth = DateTime.Now;
#endregion

//via parametro o position
WriteLine("THe first number is : {0}", arg0:number); //declaracion implicita de parametro, el argumento0 va a ser number

//Interpolacion
WriteLine($"number {number}, float {number1}, double {number2} \n");

//tipos de datos y tarea
WriteLine($"Size of an int is : {sizeof(int)}");
WriteLine($"Min size {int.MinValue}, Max size {int.MaxValue}\n");

WriteLine($"Size of an float is : {sizeof(float)}");
WriteLine($"Min size {float.MinValue}, Max size {float.MaxValue}\n");


WriteLine($"Size of an char is : {sizeof(char)}");
WriteLine($"Min size {char.MinValue}, Max size {char.MaxValue}\n");


WriteLine($"Size of an double is : {sizeof(double)}");
WriteLine($"Min size {double.MinValue}, Max size {double.MaxValue}\n");


WriteLine($"Size of an long is : {sizeof(long)}");
WriteLine($"Min size {long.MinValue}, Max size {long.MaxValue}\n");



//como generar un bigInt con menos memoria, de tarea

//

//al flotante se le llama single point presition, de pueden sumar 2 doubles
//la prescicion es lo unico que tiene diferencia
//"Si no te importan los decimales, usa flotante"
//Para mejor presicion o como se escriba, es mejor usar un tipo llamado "Decimal"
//para la computadora las fracciones es muy desgastante

